# Tessera — AI Study Detective

Don't just learn what you got wrong. Discover why.

Frontend for the NVIDIA × Nebius Global AI Hackathon (TanStack Start + React + Tailwind).
Subject: Probability & Statistics.

## Run
```sh
npm install
npm run dev      # http://localhost:3000 (or the port Vite prints)
npm run build
npm run lint
npm test
```

## Journey
Landing → Overview → Diagnose → Results → Root Cause Replay → Knowledge Map →
Learning Path → Concept lesson (practice) → Overview. Progress is saved in your browser's
local storage; **Settings → Reset demo** or **Progress → Retake diagnostic** clears it.

## Structure
- `src/routes` — thin route files (generated `routeTree.gen.ts` refreshes on dev/build)
- `src/pages` — screens
- `src/engine/diagnose.ts` — deterministic scoring, gaps, hypotheses, path
- `src/data` — concepts, questions, lessons, practice
- `src/state/AppState.tsx` — reducer + local persistence
- `src/services` — replaceable explanation layer; see `docs/BACKEND_CONTRACT.md`
