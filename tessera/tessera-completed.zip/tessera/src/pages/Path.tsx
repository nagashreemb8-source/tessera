import { Link } from "@tanstack/react-router";
import { ArrowRight, Check, Clock, Undo2 } from "lucide-react";
import { Bar, EmptyState, PageHeader, StatusPill } from "@/components/ui/tessera";
import { CONCEPT_BY_ID, conceptName } from "@/data/concepts";
import { cn } from "@/lib/utils";
import { useTessera } from "@/state/AppState";

export function PathPage() {
  const { state, dispatch, statuses, path } = useTessera();

  if (!state.diagnosis || !statuses) {
    return (
      <>
        <PageHeader eyebrow="Learning path" title="Your personalised path" />
        <EmptyState title="No path yet" body="Your path is built from your diagnostic results, so Tessera needs them first." />
      </>
    );
  }

  if (path.length === 0) {
    return (
      <>
        <PageHeader eyebrow="Learning path" title="Your personalised path" />
        <EmptyState title="Nothing to review right now" body="Every concept you were tested on looked solid. Explore the knowledge map to see what's next.">
          <Link to="/app/map" className="btn btn-primary">
            Open knowledge map
          </Link>
        </EmptyState>
      </>
    );
  }

  const done = (id: string) => state.completedSteps.some((c) => c === id);
  const completed = path.filter((s) => done(s.conceptId)).length;
  const minutesTotal = path.reduce((m, s) => m + CONCEPT_BY_ID[s.conceptId].minutes, 0);
  const minutesLeft = path.filter((s) => !done(s.conceptId)).reduce((m, s) => m + CONCEPT_BY_ID[s.conceptId].minutes, 0);
  const next = path.find((s) => !done(s.conceptId));

  return (
    <>
      <PageHeader
        eyebrow="Learning path"
        title="Your personalised path"
        sub="Ordered so that no lesson comes before the concepts it builds on. Finish a lesson's practice to complete the step."
        actions={
          next ? (
            <Link to="/app/concept/$id" params={{ id: next.conceptId }} className="btn btn-primary">
              {completed === 0 ? "Start" : "Continue"}: {conceptName(next.conceptId)} <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          ) : (
            <Link to="/app" className="btn btn-primary">
              Back to overview
            </Link>
          )
        }
      />

      <section className="panel mb-6 p-5" aria-label="Path progress">
        <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
          <span className="font-medium">
            {completed} of {path.length} steps complete
          </span>
          <span className="flex items-center gap-1.5 text-muted-foreground">
            <Clock className="h-3.5 w-3.5" aria-hidden="true" />
            {minutesLeft === 0 ? "All done" : `about ${minutesLeft} of ${minutesTotal} min left`}
          </span>
        </div>
        <div className="mt-3">
          <Bar value={completed / path.length} label={`${completed} of ${path.length} learning steps complete`} />
        </div>
        {completed === path.length && (
          <p className="mt-4 text-sm text-primary" role="status">
            Path complete. Retake the diagnostic from Progress to see how your picture has changed.
          </p>
        )}
      </section>

      <ol className="space-y-3">
        {path.map((s, i) => {
          const c = CONCEPT_BY_ID[s.conceptId];
          const isDone = done(s.conceptId);
          const waiting = s.prerequisitesInPath.filter((p) => !done(p));
          const isNext = next?.conceptId === s.conceptId;
          return (
            <li key={s.conceptId} className={cn("panel p-5 transition-colors", isNext && "border-primary/50", isDone && "opacity-80")}>
              <div className="flex flex-col gap-4 md:flex-row md:items-center">
                <div className="flex items-start gap-4 md:flex-1">
                  <span
                    className={cn(
                      "grid h-9 w-9 shrink-0 place-items-center rounded-full border text-sm font-semibold",
                      isDone ? "border-primary bg-primary text-primary-foreground" : "border-border-strong text-muted-foreground",
                    )}
                    aria-hidden="true"
                  >
                    {isDone ? <Check className="h-4 w-4" /> : i + 1}
                  </span>
                  <div className="min-w-0">
                    <p className="text-xs uppercase tracking-wider text-muted-foreground">
                      Step {i + 1} · {s.verb}
                      {isDone && " · complete"}
                    </p>
                    <h2 className="mt-0.5 text-2xl">{c.name}</h2>
                    <p className="mt-1 text-sm text-muted-foreground">{s.reason}</p>
                    <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                      <StatusPill status={statuses[s.conceptId]} />
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" aria-hidden="true" /> {c.minutes} min
                      </span>
                      {!isDone && waiting.length > 0 && <span>Best after {waiting.map(conceptName).join(" and ")}</span>}
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 md:justify-end">
                  <Link to="/app/concept/$id" params={{ id: s.conceptId }} className={cn("btn", isNext ? "btn-primary" : "btn-secondary")}>
                    {isDone ? "Review lesson" : "Open lesson"}
                  </Link>
                  {isDone && (
                    <button
                      type="button"
                      className="btn btn-quiet"
                      onClick={() => dispatch({ type: "toggleStep", conceptId: s.conceptId })}
                      aria-label={`Mark ${c.name} as not complete`}
                    >
                      <Undo2 className="h-4 w-4" aria-hidden="true" /> Undo
                    </button>
                  )}
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </>
  );
}
