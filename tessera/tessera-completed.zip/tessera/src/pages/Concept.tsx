import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, CheckCircle2, Clock, RotateCcw, XCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { StillConfused } from "@/components/StillConfused";
import { EmptyState, PageHeader, StatusPill } from "@/components/ui/tessera";
import { CONCEPT_BY_ID, conceptName, isConceptId } from "@/data/concepts";
import { CONCEPT_CONTENT } from "@/data/conceptContent";
import { PRACTICE, practiceComplete } from "@/data/practice";
import { cn } from "@/lib/utils";
import { useTessera } from "@/state/AppState";
import type { ConceptId, OptionKey } from "@/types";

const KEYS: OptionKey[] = ["A", "B", "C", "D"];

export function ConceptPage({ id }: { id: string }) {
  if (!isConceptId(id)) {
    return (
      <>
        <PageHeader eyebrow="Lesson" title="Concept not found" />
        <EmptyState title="That concept doesn't exist" body="Pick a concept from the knowledge map or your learning path.">
          <Link to="/app/map" className="btn btn-primary">
            Open knowledge map
          </Link>
          <Link to="/app/path" className="btn btn-secondary">
            Learning path
          </Link>
        </EmptyState>
      </>
    );
  }
  return <Lesson conceptId={id} />;
}

function Lesson({ conceptId }: { conceptId: ConceptId }) {
  const { state, dispatch, statuses, path } = useTessera();
  const [picks, setPicks] = useState<Record<string, OptionKey>>({});
  const concept = CONCEPT_BY_ID[conceptId];
  const content = CONCEPT_CONTENT[conceptId];
  const questions = PRACTICE[conceptId];
  const completed = state.completedSteps.includes(conceptId);
  const gap = state.diagnosis?.gaps.find((g) => g.conceptId === conceptId);
  const nextStep = path.find((s) => s.conceptId !== conceptId && !state.completedSteps.includes(s.conceptId));

  const check = (qid: string) => {
    const option = picks[qid];
    const q = questions.find((x) => x.id === qid);
    if (!option || !q) return;
    dispatch({ type: "practiceAnswer", key: qid, option });
    const after = { ...state.lessonAnswers, [qid]: option };
    if (practiceComplete(conceptId, after) && !completed) {
      dispatch({ type: "completeLesson", conceptId });
      toast.success(`${concept.name} complete`, { description: "Your path, map and overview are updated." });
    }
  };

  const answeredCount = questions.filter((q) => state.lessonAnswers[q.id] === q.correct).length;
  const maxBar = Math.max(...content.bars.map((b) => b.value), 0.01);

  return (
    <>
      <nav aria-label="Lesson navigation" className="mb-4">
        <Link to="/app/path" className="btn btn-quiet -ml-3">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Learning path
        </Link>
      </nav>

      <PageHeader
        eyebrow="Lesson"
        title={concept.name}
        sub={concept.description}
        actions={
          <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            {statuses && <StatusPill status={statuses[conceptId]} />}
            <span className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" aria-hidden="true" /> {concept.minutes} min
            </span>
          </div>
        }
      />

      {concept.prerequisites.length > 0 && (
        <p className="-mt-4 mb-6 text-sm text-muted-foreground">
          Builds on:{" "}
          {concept.prerequisites.map((p, i) => (
            <span key={p}>
              {i > 0 && ", "}
              <Link to="/app/concept/$id" params={{ id: p }} className="text-foreground underline decoration-border-strong underline-offset-4 hover:decoration-primary">
                {conceptName(p)}
              </Link>
            </span>
          ))}
        </p>
      )}

      {gap && (
        <p className="mb-6 rounded-md border border-border bg-surface-2 p-4 text-sm text-muted-foreground">
          <span className="font-medium text-foreground">Why this lesson? </span>
          {gap.summary} This is a hypothesis from a short diagnostic, not a conclusion.
        </p>
      )}

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <div className="space-y-5">
          <section className="panel p-6" aria-labelledby="explain">
            <h2 id="explain" className="text-2xl">
              The idea
            </h2>
            <div className="mt-3 space-y-3 leading-relaxed">
              {content.explanation.map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>
            <p className="mt-4 overflow-x-auto rounded-md border border-border bg-surface-2 px-4 py-3 font-mono text-sm">{content.formula}</p>
          </section>

          <section className="panel p-6" aria-labelledby="example">
            <h2 id="example" className="text-2xl">
              Worked example
            </h2>
            <p className="mt-3 font-display text-lg">{content.example.prompt}</p>
            <ol className="mt-4 space-y-2 text-sm">
              {content.example.steps.map((s, i) => (
                <li key={i} className="flex gap-3">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-surface-2 text-xs text-muted-foreground" aria-hidden="true">
                    {i + 1}
                  </span>
                  <span className="pt-0.5">{s}</span>
                </li>
              ))}
            </ol>
            <p className="mt-4 rounded-md bg-primary/10 px-4 py-2 text-sm font-medium text-primary">Answer: {content.example.answer}</p>
          </section>

          <section className="panel p-6" aria-labelledby="visual">
            <h2 id="visual" className="text-xl">
              See it
            </h2>
            <div className="mt-5 flex h-32 items-end gap-3" role="img" aria-label={content.barsCaption}>
              {content.bars.map((b, i) => (
                <div key={i} className="flex flex-1 flex-col items-center justify-end gap-1.5">
                  <div className="w-full max-w-14 rounded-t-sm bg-primary/70" style={{ height: `${Math.max(2, (b.value / maxBar) * 100)}%` }} />
                  <span className="text-[11px] text-muted-foreground">{b.label}</span>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs text-muted-foreground">{content.barsCaption}</p>
          </section>
        </div>

        <section className="panel h-fit p-6 lg:sticky lg:top-20" aria-labelledby="practice">
          <div className="flex items-center justify-between">
            <h2 id="practice" className="text-2xl">
              Practice
            </h2>
            <span className="text-xs text-muted-foreground">
              {answeredCount} of {questions.length} correct
            </span>
          </div>

          <div className="mt-5 space-y-7">
            {questions.map((q, qi) => {
              const submitted = state.lessonAnswers[q.id];
              const picked = picks[q.id];
              const right = submitted === q.correct;
              return (
                <fieldset key={q.id}>
                  <legend className="font-display text-lg leading-snug">
                    <span className="mr-2 text-muted-foreground">{qi + 1}.</span>
                    {q.prompt}
                  </legend>
                  <div role="radiogroup" className="mt-3 grid gap-2">
                    {KEYS.map((k) => {
                      const selected = (submitted ?? picked) === k;
                      const showCorrect = submitted !== undefined && k === q.correct;
                      const showWrong = submitted === k && !right;
                      return (
                        <label
                          key={k}
                          className={cn(
                            "flex min-h-12 items-center gap-3 rounded-md border px-3 text-sm transition-colors focus-within:outline-2 focus-within:outline-primary",
                            submitted === undefined ? "cursor-pointer" : "cursor-default",
                            showCorrect && "border-primary bg-primary/10",
                            showWrong && "border-developing bg-developing/10",
                            !showCorrect && !showWrong && (selected ? "border-primary bg-primary/10" : "border-border hover:border-border-strong"),
                          )}
                        >
                          <input
                            type="radio"
                            name={q.id}
                            value={k}
                            checked={selected}
                            disabled={submitted !== undefined}
                            onChange={() => setPicks((p) => ({ ...p, [q.id]: k }))}
                            className="sr-only"
                          />
                          <span className="text-xs font-semibold text-muted-foreground">{k}</span>
                          {q.options[k]}
                        </label>
                      );
                    })}
                  </div>

                  {submitted === undefined ? (
                    <button type="button" className="btn btn-primary mt-3" disabled={!picked} onClick={() => check(q.id)}>
                      Check answer
                    </button>
                  ) : (
                    <div className="animate-fade-up mt-3" role="status" aria-live="polite">
                      <p className={cn("flex items-center gap-2 text-sm font-medium", right ? "text-primary" : "text-developing")}>
                        {right ? <CheckCircle2 className="h-4 w-4" aria-hidden="true" /> : <XCircle className="h-4 w-4" aria-hidden="true" />}
                        {right ? "Correct" : "Not quite"}
                      </p>
                      {!right && q.wrongNotes[submitted] && <p className="mt-1 text-sm text-muted-foreground">{q.wrongNotes[submitted]}</p>}
                      <p className="mt-1 text-sm text-muted-foreground">{q.explanation}</p>
                      {!right && (
                        <button
                          type="button"
                          className="btn btn-secondary mt-3"
                          onClick={() => {
                            dispatch({ type: "practiceReset", key: q.id });
                            setPicks((p) => {
                              const n = { ...p };
                              delete n[q.id];
                              return n;
                            });
                          }}
                        >
                          <RotateCcw className="h-4 w-4" aria-hidden="true" /> Try again
                        </button>
                      )}
                    </div>
                  )}
                </fieldset>
              );
            })}
          </div>

          <div className="mt-7 flex items-center justify-between gap-2 border-t border-border pt-4">
            <p className="text-xs text-muted-foreground">Answer both correctly to complete this lesson.</p>
            <StillConfused conceptId={conceptId} questionIds={gap?.supportingQuestionIds} />
          </div>
        </section>
      </div>

      {completed && (
        <section className="panel animate-fade-up mt-6 border-primary/40 p-6" role="status" aria-label="Lesson complete">
          <p className="eyebrow flex items-center gap-2 text-primary">
            <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" /> Lesson complete
          </p>
          <h2 className="mt-2 text-2xl">{concept.name} is now marked as mastered.</h2>
          <p className="mt-1 text-sm text-muted-foreground">Your knowledge map, path and overview have been updated.</p>
          <div className="mt-5 flex flex-wrap gap-2">
            {nextStep && (
              <Link to="/app/concept/$id" params={{ id: nextStep.conceptId }} className="btn btn-primary">
                Next: {conceptName(nextStep.conceptId)} <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            )}
            <Link to="/app/path" className="btn btn-secondary">
              Learning path
            </Link>
            <Link to="/app" className={cn("btn", nextStep ? "btn-quiet" : "btn-primary")}>
              Back to overview
            </Link>
          </div>
        </section>
      )}
    </>
  );
}
