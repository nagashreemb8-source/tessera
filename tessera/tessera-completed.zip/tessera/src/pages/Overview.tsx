import { Link } from "@tanstack/react-router";
import { AlertTriangle, ArrowRight, RotateCw, Sparkles } from "lucide-react";
import { useState } from "react";
import { Bar, EmptyState, PageHeader, StatusPill } from "@/components/ui/tessera";
import { CONCEPTS, conceptName } from "@/data/concepts";
import { QUESTIONS } from "@/data/questions";
import { SAMPLE_STUDENT, SAMPLE_WEEK } from "@/data/sampleStudent";
import { useTessera } from "@/state/AppState";

export function OverviewPage() {
  const { state, dispatch, statuses, path } = useTessera();
  const [retrying, setRetrying] = useState(false);

  const header = (
    <PageHeader
      eyebrow={SAMPLE_STUDENT.subject}
      title="Your learning, decoded."
      sub="See what you understand, what needs attention, and what to explore next."
    />
  );

  if (state.simulateFailure) {
    return (
      <>
        {header}
        <div role="alert" className="panel flex flex-col items-start gap-4 p-8">
          <AlertTriangle className="h-6 w-6 text-developing" aria-hidden="true" />
          <div>
            <h2 className="text-2xl">Your overview didn't load</h2>
            <p className="mt-1 text-sm text-muted-foreground">This is a simulated failure for the demo. Your answers are safe in memory.</p>
          </div>
          <button
            type="button"
            className="btn btn-secondary"
            disabled={retrying}
            onClick={() => {
              setRetrying(true);
              setTimeout(() => {
                dispatch({ type: "simulateFailure", value: false });
                setRetrying(false);
              }, 600);
            }}
          >
            <RotateCw className={retrying ? "h-4 w-4 animate-spin" : "h-4 w-4"} aria-hidden="true" /> {retrying ? "Retrying…" : "Retry"}
          </button>
        </div>
      </>
    );
  }

  if (!state.diagnosis || !statuses) {
    const inProgress = QUESTIONS.filter((q) => state.answers[q.id]).length;
    return (
      <>
        {header}
        <EmptyState
          title={inProgress > 0 ? "Diagnostic in progress" : "No diagnostic yet"}
          body={
            inProgress > 0
              ? `You've answered ${inProgress} of ${QUESTIONS.length} questions. Pick up where you left off.`
              : "Take the 8-question diagnostic to see which concepts look solid and which might need a closer look."
          }
        >
          <Link to="/app/diagnose" className="btn btn-primary">
            {inProgress > 0 ? "Resume diagnostic" : "Start a diagnostic"}
          </Link>
          <button type="button" className="btn btn-secondary" onClick={() => dispatch({ type: "loadSampleResults" })}>
            Load sample results
          </button>
        </EmptyState>
      </>
    );
  }

  const counts = { mastered: 0, developing: 0, untested: 0 };
  CONCEPTS.forEach((c) => counts[statuses[c.id]]++);
  const top = state.diagnosis.gaps[0];
  const firstOpen = path.find((s) => !state.completedSteps.includes(s.conceptId));
  const maxMin = Math.max(...SAMPLE_WEEK.map((d) => d.minutes));
  const strengths = CONCEPTS.filter((c) => statuses[c.id] === "mastered");
  const watch = CONCEPTS.filter((c) => statuses[c.id] === "developing");
  const untested = CONCEPTS.filter((c) => statuses[c.id] === "untested");

  return (
    <>
      {header}
      <div className="grid gap-5 lg:grid-cols-3">
        <section className="panel relative overflow-hidden p-7 lg:col-span-2" aria-labelledby="next">
          <div className="bg-hero pointer-events-none absolute inset-0 opacity-70" aria-hidden="true" />
          <div className="relative">
            <p className="eyebrow flex items-center gap-2 text-primary">
              <Sparkles className="h-3.5 w-3.5" aria-hidden="true" /> Your next breakthrough
            </p>
            {top ? (
              <>
                <h2 id="next" className="mt-4 max-w-xl text-3xl">
                  {top.kind === "prerequisite" && top.dependentConceptIds[0]
                    ? `Review ${conceptName(top.conceptId).toLowerCase()} before moving deeper into ${conceptName(top.dependentConceptIds[0]).toLowerCase()}.`
                    : `Take a closer look at ${conceptName(top.conceptId).toLowerCase()}.`}
                </h2>
                <p className="mt-3 max-w-xl text-sm text-muted-foreground">{top.summary}</p>
                <Link to="/app/replay" className="btn btn-primary mt-6">
                  Investigate <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
              </>
            ) : (
              <>
                <h2 id="next" className="mt-4 text-3xl">No suspected gaps in this diagnostic.</h2>
                <p className="mt-3 text-sm text-muted-foreground">Every tested concept looked solid. The Central Limit Theorem is next to assess.</p>
                <Link to="/app/path" className="btn btn-primary mt-6">
                  Open learning path
                </Link>
              </>
            )}
          </div>
        </section>

        <section className="panel p-6" aria-labelledby="mastery">
          <p className="eyebrow">Overall mastery</p>
          <p id="mastery" className="mt-3 font-display text-5xl">
            {counts.mastered}
            <span className="text-2xl text-muted-foreground"> / {CONCEPTS.length}</span>
          </p>
          <p className="text-sm text-muted-foreground">concepts mastered</p>
          <div className="mt-4">
            <Bar value={counts.mastered / CONCEPTS.length} label={`${counts.mastered} of ${CONCEPTS.length} concepts mastered`} />
          </div>
          <dl className="mt-5 space-y-2 text-sm">
            {(["mastered", "developing", "untested"] as const).map((s) => (
              <div key={s} className="flex items-center justify-between">
                <dt>
                  <StatusPill status={s} />
                </dt>
                <dd className="font-medium tabular-nums">{counts[s]}</dd>
              </div>
            ))}
          </dl>
        </section>

        <section className="panel p-6 lg:col-span-3" aria-labelledby="sg">
          <h2 id="sg" className="text-xl">
            Strengths and areas to explore
          </h2>
          <div className="mt-4 grid gap-5 md:grid-cols-3">
            {(
              [
                ["Strengths", strengths, "No concept has been demonstrated yet."],
                ["Possible gaps", watch, "No possible gaps right now."],
                ["Not yet assessed", untested, "Everything has been assessed."],
              ] as const
            ).map(([title, list, none]) => (
              <div key={title}>
                <p className="eyebrow">{title}</p>
                {list.length === 0 ? (
                  <p className="mt-2 text-sm text-muted-foreground">{none}</p>
                ) : (
                  <ul className="mt-2 flex flex-wrap gap-1.5">
                    {list.map((c) => (
                      <li key={c.id}>
                        <Link to="/app/concept/$id" params={{ id: c.id }} className="btn btn-secondary h-8 min-h-8 px-3 text-xs">
                          {c.name}
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </section>

        <section className="panel p-6" aria-labelledby="activity">
          <h2 id="activity" className="text-xl">Recent activity</h2>
          {state.activity.length === 0 && <p className="mt-3 text-sm text-muted-foreground">Nothing yet.</p>}
          <ol className="mt-4 space-y-3">
            {state.activity.slice(0, 5).map((a) => (
              <li key={a.id} className="border-l border-border pl-3">
                <p className="text-sm font-medium">{a.label}</p>
                <p className="text-xs text-muted-foreground">{a.detail}</p>
              </li>
            ))}
          </ol>
        </section>

        <section className="panel p-6" aria-labelledby="week">
          <div className="flex items-center justify-between">
            <h2 id="week" className="text-xl">This week</h2>
            <span className="text-[11px] text-muted-foreground">Sample data</span>
          </div>
          <div className="mt-6 flex h-28 items-end gap-2" role="img" aria-label="Sample study minutes per day this week">
            {SAMPLE_WEEK.map((d) => (
              <div key={d.day} className="flex flex-1 flex-col items-center gap-1.5">
                <div className="w-full rounded-sm bg-primary/70" style={{ height: `${Math.max(4, (d.minutes / maxMin) * 96)}px` }} />
                <span className="text-[10px] text-muted-foreground">{d.day}</span>
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs text-muted-foreground">Study minutes per day (illustrative).</p>
        </section>

        <section className="panel p-6" aria-labelledby="up-next">
          <h2 id="up-next" className="text-xl">Learning path</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {state.completedSteps.length} of {path.length} steps complete
          </p>
          <div className="mt-3">
            <Bar value={path.length ? state.completedSteps.length / path.length : 0} label="Learning path progress" />
          </div>
          {firstOpen && (
            <p className="mt-4 text-sm">
              Up next: <span className="font-medium">{firstOpen.verb} {conceptName(firstOpen.conceptId)}</span>
            </p>
          )}
          <div className="mt-4 flex flex-wrap gap-2">
            {firstOpen && (
              <Link to="/app/concept/$id" params={{ id: firstOpen.conceptId }} className="btn btn-primary">
                {state.completedSteps.length === 0 ? "Start" : "Continue"} lesson
              </Link>
            )}
            <Link to="/app/path" className="btn btn-secondary">
              Open path
            </Link>
          </div>
        </section>
      </div>
    </>
  );
}
