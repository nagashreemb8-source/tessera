import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowDown, CheckCircle2, FlaskConical, HelpCircle, Plus, RotateCcw, ShieldCheck, TriangleAlert } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { StillConfused } from "@/components/StillConfused";
import { EmptyState, EvidenceMeter, PageHeader, StatusPill } from "@/components/ui/tessera";
import { CONCEPT_BY_ID, conceptName } from "@/data/concepts";
import { QUESTION_BY_ID } from "@/data/questions";
import { evaluateHypothesis } from "@/engine/diagnose";
import { cn } from "@/lib/utils";
import { useTessera } from "@/state/AppState";
import type { ConceptId, HypothesisOutcome, OptionKey, SuspectedGap } from "@/types";

const OUTCOME_STYLE: Record<HypothesisOutcome, { icon: typeof CheckCircle2; cls: string }> = {
  "possible-gap": { icon: TriangleAlert, cls: "border-developing/50 bg-developing/10 text-developing" },
  "more-evidence": { icon: HelpCircle, cls: "border-violet/50 bg-violet/10 text-violet" },
  supported: { icon: ShieldCheck, cls: "border-primary/50 bg-primary/10 text-primary" },
};

function trailFor(g: SuspectedGap): ConceptId[] {
  const up = CONCEPT_BY_ID[g.conceptId].prerequisites[0];
  const chain: ConceptId[] = [];
  if (g.kind === "prerequisite" && g.dependentConceptIds[0]) chain.push(g.dependentConceptIds[0]);
  chain.push(g.conceptId);
  if (up) chain.push(up);
  return chain;
}

export function ReplayPage({ concept }: { concept?: ConceptId | undefined }) {
  const { state, dispatch, statuses } = useTessera();
  const navigate = useNavigate();
  const gaps = state.diagnosis?.gaps ?? [];
  const gap = gaps.find((g) => g.conceptId === concept) ?? gaps[0];
  const [selectedQ, setSelectedQ] = useState<number | null>(null);
  const [testing, setTesting] = useState(false);
  const [pick, setPick] = useState<OptionKey | null>(null);

  if (!state.diagnosis || !statuses) {
    return (
      <>
        <PageHeader eyebrow="Root Cause Replay" title="Nothing to investigate yet" />
        <EmptyState title="Run a diagnostic first" body="Root Cause Replay traces your answers back through prerequisite concepts. It needs answers to work with." />
      </>
    );
  }
  if (!gap) {
    return (
      <>
        <PageHeader eyebrow="Root Cause Replay" title="No suspected gaps" />
        <EmptyState title="Every tested concept looked solid" body="There's nothing to trace back this time. Explore the knowledge map to see what's next.">
          <Link to="/app/map" className="btn btn-primary">
            Open knowledge map
          </Link>
        </EmptyState>
      </>
    );
  }

  const qId = selectedQ && gap.supportingQuestionIds.includes(selectedQ) ? selectedQ : gap.supportingQuestionIds[0]!;
  const q = QUESTION_BY_ID[qId]!;
  const chosen = state.answers[qId];
  const trail = trailFor(gap) as [ConceptId, ...ConceptId[]];
  const result = state.hypotheses[gap.conceptId];
  const fu = gap.followUp;

  const runTest = () => {
    if (!pick) return;
    const r = evaluateHypothesis(gap.conceptId, pick);
    dispatch({ type: "hypothesis", result: r });
    toast(r.title, { description: `${conceptName(gap.conceptId)} status updated.` });
  };

  return (
    <>
      <PageHeader
        eyebrow="Root Cause Replay"
        title={`Why did ${conceptName(trail[0]).toLowerCase()} go wrong?`}
        sub="Tessera is testing a hypothesis about a concept, not judging you."
        actions={
          gaps.length > 1 ? (
            <div className="flex flex-wrap gap-1" role="tablist" aria-label="Suspected gaps">
              {gaps.map((g) => (
                <button
                  key={g.conceptId}
                  role="tab"
                  aria-selected={g.conceptId === gap.conceptId}
                  className={cn("btn h-9 text-xs", g.conceptId === gap.conceptId ? "btn-secondary" : "btn-quiet")}
                  onClick={() => {
                    setSelectedQ(null);
                    setTesting(false);
                    setPick(null);
                    navigate({ to: "/app/replay", search: { concept: g.conceptId } });
                  }}
                >
                  {conceptName(g.conceptId)}
                </button>
              ))}
            </div>
          ) : undefined
        }
      />

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_280px_minmax(0,1.15fr)]">
        {/* Evidence */}
        <section className="panel p-5" aria-labelledby="ev">
          <p id="ev" className="eyebrow">Evidence</p>
          <ul className="mt-3 flex flex-wrap gap-1.5" role="listbox" aria-label="Supporting questions">
            {gap.supportingQuestionIds.map((id) => (
              <li key={id}>
                <button
                  type="button"
                  role="option"
                  aria-selected={id === qId}
                  onClick={() => setSelectedQ(id)}
                  className={cn(
                    "h-9 rounded-md border px-3 text-sm transition-colors",
                    id === qId ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:border-border-strong hover:text-foreground",
                  )}
                >
                  Q{id} · {conceptName(QUESTION_BY_ID[id]!.conceptIds[0]!).split(" ")[0]}
                </button>
              </li>
            ))}
          </ul>
          <div key={qId} className="animate-fade-up mt-5">
            <p className="text-xs text-muted-foreground">Observed · Question {qId}</p>
            <p className="mt-1 font-display text-lg leading-snug">{q.prompt}</p>
            <dl className="mt-4 grid grid-cols-2 gap-2 text-sm">
              <div className="panel-raised p-3">
                <dt className="text-xs text-muted-foreground">Your answer</dt>
                <dd className="mt-1 font-medium text-developing">{chosen ? `${chosen} · ${q.options[chosen]}` : "—"}</dd>
              </div>
              <div className="panel-raised p-3">
                <dt className="text-xs text-muted-foreground">Correct</dt>
                <dd className="mt-1 font-medium text-primary">
                  {q.correct} · {q.options[q.correct]}
                </dd>
              </div>
            </dl>
            <p className="mt-4 text-xs font-medium uppercase tracking-wider text-muted-foreground">Observed error pattern</p>
            <p className="mt-1 text-sm">{(chosen && q.commonErrors[chosen]) ?? "A less common answer; no specific pattern named."}</p>
          </div>
        </section>

        {/* Concept trail */}
        <section className="panel relative overflow-hidden p-5" aria-labelledby="trail">
          <div className="grid-lines pointer-events-none absolute inset-0 opacity-30" aria-hidden="true" />
          <p id="trail" className="eyebrow relative">Concept trail</p>
          <ol className="relative mt-5 flex flex-col items-stretch">
            {trail.map((id, i) => {
              const focus = id === gap.conceptId;
              return (
                <li key={id} className="flex flex-col items-center">
                  {i > 0 && (
                    <div className="flex h-12 flex-col items-center" aria-hidden="true">
                      <svg width="12" height="48">
                        <line x1="6" y1="0" x2="6" y2="40" strokeWidth="1.5" className={cn(i === 1 || focus ? "stroke-primary animate-dash" : "stroke-muted-foreground/40")} />
                      </svg>
                    </div>
                  )}
                  <Link
                    to="/app/concept/$id"
                    params={{ id }}
                    className={cn(
                      "block w-full rounded-lg border p-4 transition-all",
                      focus ? "border-primary bg-surface-2 glow-ring" : "border-border bg-surface hover:border-border-strong",
                    )}
                  >
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                      {i === 0 && trail.length > 2 ? "Where it showed up" : focus ? "Under investigation" : "Builds on"}
                    </span>
                    <span className="mt-1 block font-display text-lg">{conceptName(id)}</span>
                    <StatusPill status={statuses[id]} className="mt-2" />
                  </Link>
                </li>
              );
            })}
          </ol>
          <p className="relative mt-5 flex items-center justify-center gap-1 text-[11px] text-muted-foreground">
            <ArrowDown className="h-3 w-3" aria-hidden="true" /> advanced → foundational
          </p>
        </section>

        {/* Investigation result */}
        <section className="panel p-5" aria-labelledby="inv">
          <p id="inv" className="eyebrow">Investigation result</p>
          <p className="mt-4 text-[11px] font-semibold uppercase tracking-wider text-primary">
            {gap.needsMoreEvidence ? "More evidence needed" : gap.kind === "prerequisite" ? "Possible foundational gap" : "Possible gap"}
          </p>
          <h2 className="mt-1 text-3xl">{conceptName(gap.conceptId)}</h2>
          <p className="mt-3 text-sm text-muted-foreground">{gap.summary}</p>
          {gap.supportedPrerequisites.length > 0 && (
            <p className="mt-2 text-sm text-muted-foreground">
              Prerequisite understanding supported: {gap.supportedPrerequisites.map(conceptName).join(", ")}.
            </p>
          )}

          <div className="mt-5">
            <EvidenceMeter level={gap.evidence} />
            <p className="mt-1 text-xs text-muted-foreground">{gap.supportingQuestionIds.length} supporting answer(s): {gap.supportingQuestionIds.map((i) => `Q${i}`).join(", ")}</p>
          </div>

          <div className="mt-5">
            <p className="text-sm font-medium">Other explanations to consider</p>
            <ul className="mt-2 space-y-1.5 text-sm text-muted-foreground">
              {gap.alternatives.map((a) => (
                <li key={a} className="flex gap-2">
                  <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-muted-foreground" aria-hidden="true" />
                  {a}
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-6 border-t border-border pt-5">
            {!fu ? (
              <p className="text-sm text-muted-foreground">No follow-up question is available for this concept yet.</p>
            ) : result ? (
              <div className="animate-fade-up" aria-live="polite">
                {(() => {
                  const S = OUTCOME_STYLE[result.outcome];
                  return (
                    <div className={cn("rounded-lg border p-4", S.cls)}>
                      <p className="flex items-center gap-2 font-medium">
                        <S.icon className="h-4 w-4" aria-hidden="true" /> {result.title}
                      </p>
                      <p className="mt-2 text-sm text-foreground">{result.explanation}</p>
                      <p className="mt-2 text-xs text-muted-foreground">
                        You chose {result.answer}: {fu.options[result.answer]}. Status now: {statuses[gap.conceptId]}.
                      </p>
                    </div>
                  );
                })()}
                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => {
                      dispatch({ type: "log", label: "Added to learning path", detail: conceptName(gap.conceptId) });
                      toast.success(`${conceptName(gap.conceptId)} is in your learning path`);
                      navigate({ to: "/app/path" });
                    }}
                  >
                    <Plus className="h-4 w-4" aria-hidden="true" /> Add to learning path
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => {
                      setPick(null);
                      setTesting(true);
                      dispatch({ type: "log", label: "Retrying follow-up", detail: conceptName(gap.conceptId) });
                    }}
                  >
                    <RotateCcw className="h-4 w-4" aria-hidden="true" /> Answer again
                  </button>
                </div>
              </div>
            ) : !testing ? (
              <button type="button" className="btn btn-primary h-12 w-full text-base" onClick={() => setTesting(true)}>
                <FlaskConical className="h-4 w-4" aria-hidden="true" /> Test this hypothesis
              </button>
            ) : null}

            {fu && testing && (!result || pick === null) && (
              <fieldset className={cn("animate-fade-up", result && "mt-5")}>
                <legend className="text-sm font-medium">Follow-up question</legend>
                <p className="mt-2 font-display text-lg leading-snug">{fu.prompt}</p>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  {(Object.keys(fu.options) as OptionKey[]).map((k) => (
                    <label
                      key={k}
                      className={cn(
                        "flex min-h-12 cursor-pointer items-center gap-3 rounded-md border px-3 text-sm transition-all focus-within:outline-2 focus-within:outline-primary",
                        pick === k ? "border-primary bg-primary/10" : "border-border hover:border-border-strong",
                      )}
                    >
                      <input type="radio" name="followup" className="sr-only" checked={pick === k} onChange={() => setPick(k)} />
                      <span className="text-xs font-semibold text-muted-foreground">{k}</span>
                      {fu.options[k]}
                    </label>
                  ))}
                </div>
                <button
                  type="button"
                  className="btn btn-primary mt-3 w-full"
                  disabled={!pick}
                  onClick={() => {
                    runTest();
                    setTesting(false);
                  }}
                >
                  Check my answer
                </button>
              </fieldset>
            )}
          </div>

          <div className="mt-5 flex items-center justify-between gap-2 border-t border-border pt-4">
            <p className="text-xs text-muted-foreground">Tessera is testing a hypothesis about a concept, not judging you.</p>
            <StillConfused conceptId={gap.conceptId} questionIds={gap.supportingQuestionIds} />
          </div>
        </section>
      </div>
    </>
  );
}
