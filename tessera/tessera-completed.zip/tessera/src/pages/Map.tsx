import { Link } from "@tanstack/react-router";
import { ArrowRight, Microscope } from "lucide-react";
import { useState } from "react";
import { KnowledgeGraph, MapLegend } from "@/components/map/KnowledgeGraph";
import { EmptyState, PageHeader, StatusPill } from "@/components/ui/tessera";
import { CONCEPTS, CONCEPT_BY_ID, CONCEPT_IDS, conceptName, dependentsOf, depthOf } from "@/data/concepts";
import { cn } from "@/lib/utils";
import { useTessera } from "@/state/AppState";
import type { ConceptId } from "@/types";

export function MapPage() {
  const { state, statuses } = useTessera();
  const [picked, setPicked] = useState<ConceptId | null>(null);

  if (!state.diagnosis || !statuses) {
    return (
      <>
        <PageHeader eyebrow="Knowledge map" title="How your concepts connect" />
        <EmptyState
          title="The map needs a diagnostic first"
          body="Each concept is coloured by what your answers showed. Take the diagnostic to fill the map in."
        />
      </>
    );
  }

  const investigating = state.diagnosis.gaps[0]?.conceptId ?? null;
  const defaultPick = investigating ?? CONCEPT_IDS.find((id) => statuses[id] !== "mastered") ?? CONCEPT_IDS[0]!;
  const selected = picked ?? defaultPick;
  const c = CONCEPT_BY_ID[selected];
  const gap = state.diagnosis.gaps.find((g) => g.conceptId === selected);
  const r = state.results?.concepts[selected];
  const layers = [0, 1, 2, 3].map((d) => CONCEPTS.filter((x) => depthOf(x.id) === d)).filter((l) => l.length > 0);

  return (
    <>
      <PageHeader
        eyebrow="Knowledge map"
        title="How your concepts connect"
        sub="Arrows point from a prerequisite to the concept built on it. Select any concept to see details and open its lesson."
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
        <section className="panel p-5" aria-label="Concept map">
          <div className="hidden md:block">
            <KnowledgeGraph statuses={statuses} selected={selected} investigating={investigating} onSelect={setPicked} />
          </div>

          {/* Small-screen alternative: layered list, foundations first */}
          <ol className="space-y-5 md:hidden" aria-label="Concepts by depth, foundations first">
            {layers.map((layer, i) => (
              <li key={i}>
                <p className="eyebrow mb-2">{i === 0 ? "Foundations" : `Builds on level ${i}`}</p>
                <ul className="space-y-2">
                  {layer.map((x) => (
                    <li key={x.id}>
                      <button
                        type="button"
                        onClick={() => setPicked(x.id)}
                        aria-pressed={selected === x.id}
                        className={cn(
                          "flex min-h-12 w-full items-center justify-between gap-3 rounded-lg border px-4 py-2 text-left transition-colors",
                          selected === x.id ? "border-primary bg-surface-2" : "border-border bg-surface",
                        )}
                      >
                        <span className="text-sm font-medium">{x.name}</span>
                        <StatusPill status={statuses[x.id]} />
                      </button>
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ol>

          <div className="mt-5 border-t border-border pt-4">
            <MapLegend />
          </div>
        </section>

        <aside className="panel p-6 lg:sticky lg:top-20 lg:self-start" aria-live="polite" aria-label="Selected concept">
          <StatusPill status={statuses[selected]} />
          <h2 className="mt-3 text-3xl">{c.name}</h2>
          <p className="mt-2 text-sm text-muted-foreground">{c.description}</p>

          <dl className="mt-5 space-y-4 text-sm">
            <div>
              <dt className="text-xs uppercase tracking-wider text-muted-foreground">Diagnostic result</dt>
              <dd className="mt-1">
                {r && r.answered > 0 ? `${r.correct} of ${r.answered} correct` : "Not assessed in this diagnostic"}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wider text-muted-foreground">Builds on</dt>
              <dd className="mt-1 flex flex-wrap gap-1.5">
                {c.prerequisites.length === 0 ? (
                  <span className="text-muted-foreground">Nothing: this is a foundation.</span>
                ) : (
                  c.prerequisites.map((p) => (
                    <button key={p} type="button" className="btn btn-secondary h-8 min-h-8 px-3 text-xs" onClick={() => setPicked(p)}>
                      {conceptName(p)}
                    </button>
                  ))
                )}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wider text-muted-foreground">Leads to</dt>
              <dd className="mt-1 flex flex-wrap gap-1.5">
                {dependentsOf(selected).length === 0 ? (
                  <span className="text-muted-foreground">The end of this map.</span>
                ) : (
                  dependentsOf(selected).map((d) => (
                    <button key={d} type="button" className="btn btn-secondary h-8 min-h-8 px-3 text-xs" onClick={() => setPicked(d)}>
                      {conceptName(d)}
                    </button>
                  ))
                )}
              </dd>
            </div>
          </dl>

          {gap && (
            <p className="mt-5 rounded-md border border-border bg-surface-2 p-3 text-xs text-muted-foreground">
              <span className="font-medium text-foreground">Hypothesis, not a verdict. </span>
              {gap.summary}
            </p>
          )}

          <div className="mt-6 flex flex-col gap-2">
            <Link to="/app/concept/$id" params={{ id: selected }} className="btn btn-primary">
              Open lesson · {c.minutes} min <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
            {gap && (
              <Link to="/app/replay" search={{ concept: selected }} className="btn btn-secondary">
                <Microscope className="h-4 w-4" aria-hidden="true" /> Investigate in Root Cause Replay
              </Link>
            )}
          </div>
        </aside>
      </div>
    </>
  );
}
