import { Link } from "@tanstack/react-router";
import { ArrowRight, Eye, Microscope } from "lucide-react";
import { EmptyState, EvidenceMeter, PageHeader, StatusPill } from "@/components/ui/tessera";
import { CONCEPTS, conceptName } from "@/data/concepts";
import { QUESTION_BY_ID } from "@/data/questions";
import { useTessera } from "@/state/AppState";

export function ResultsPage() {
  const { state } = useTessera();
  const { diagnosis, results } = state;
  if (!diagnosis || !results) {
    return (
      <>
        <PageHeader title="Diagnostic summary" />
        <EmptyState title="No results yet" body="Run the diagnostic first. Results show observed mistakes and suspected gaps side by side." />
      </>
    );
  }

  return (
    <>
      <PageHeader
        eyebrow="Diagnostic summary"
        title="Here's what your answers suggest."
        sub="Observed mistakes are facts. Suspected gaps are hypotheses, and every hypothesis can be tested."
        actions={
          <span className="panel-raised px-3 py-2 text-sm text-muted-foreground">
            Score {results.score}/{results.total}
            {results.answered < results.total && ` · ${results.total - results.answered} unanswered`}
          </span>
        }
      />

      <section aria-labelledby="breakdown" className="panel p-6">
        <h2 id="breakdown" className="text-xl">Concept status</h2>
        <ul className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {CONCEPTS.map((c) => {
            const r = results.concepts[c.id];
            return (
              <li key={c.id} className="panel-raised p-3">
                <p className="text-sm font-medium">{c.name}</p>
                <div className="mt-2 flex items-center justify-between">
                  <StatusPill status={diagnosis.statuses[c.id]} />
                  <span className="text-xs text-muted-foreground">{r.answered ? `${r.correct}/${r.answered} correct` : "no questions"}</span>
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <section aria-labelledby="observed" className="panel p-6">
          <h2 id="observed" className="flex items-center gap-2 text-xl">
            <Eye className="h-4 w-4 text-muted-foreground" aria-hidden="true" /> Observed mistakes
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">What you actually answered.</p>
          {diagnosis.observed.length === 0 ? (
            <p className="mt-4 text-sm text-muted-foreground">No mistakes observed.</p>
          ) : (
            <ul className="mt-4 divide-y divide-border">
              {diagnosis.observed.map((o) => {
                const q = QUESTION_BY_ID[o.questionId]!;
                return (
                  <li key={o.questionId} className="py-4">
                    <p className="text-xs text-muted-foreground">
                      Q{o.questionId} · {o.conceptIds.map(conceptName).join(", ")}
                    </p>
                    <p className="mt-1 text-sm">{q.prompt}</p>
                    <p className="mt-2 text-sm">
                      <span className="text-developing">Chose {o.chosen ? `${o.chosen} (${q.options[o.chosen]})` : "nothing"}</span>
                      <span className="text-muted-foreground"> · correct {o.correctAnswer} ({q.options[o.correctAnswer]})</span>
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">Likely pattern: {o.pattern}</p>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <section aria-labelledby="suspected" className="panel p-6">
          <h2 id="suspected" className="flex items-center gap-2 text-xl">
            <Microscope className="h-4 w-4 text-primary" aria-hidden="true" /> Suspected gaps
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">Hypotheses consistent with the pattern. Not conclusions.</p>
          {diagnosis.gaps.length === 0 ? (
            <p className="mt-4 text-sm text-muted-foreground">No gaps suspected. Nice work.</p>
          ) : (
            <ul className="mt-4 space-y-3">
              {diagnosis.gaps.map((g) => (
                <li key={g.conceptId} className="panel-raised p-4">
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-primary">
                    {g.needsMoreEvidence ? "More evidence needed" : g.kind === "prerequisite" ? "Possible foundational gap" : "Possible gap"}
                  </p>
                  <p className="mt-1 font-display text-2xl">{conceptName(g.conceptId)}</p>
                  <p className="mt-2 text-sm text-muted-foreground">{g.summary}</p>
                  <div className="mt-3">
                    <EvidenceMeter level={g.evidence} />
                  </div>
                  <Link to="/app/replay" search={{ concept: g.conceptId }} className="btn btn-primary mt-4">
                    Investigate in Root Cause Replay <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="panel mt-5 flex flex-col gap-4 p-6 md:flex-row md:items-center md:justify-between" aria-label="Next steps">
        <div>
          <h2 className="text-xl">What next?</h2>
          <p className="mt-1 text-sm text-muted-foreground">Test a hypothesis, see how concepts connect, or go straight to your learning path.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to="/app/map" className="btn btn-secondary">
            Knowledge map
          </Link>
          <Link to="/app/path" className="btn btn-primary">
            Learning path <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
        </div>
      </section>
    </>
  );
}
