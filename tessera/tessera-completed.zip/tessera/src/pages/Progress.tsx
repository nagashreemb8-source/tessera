import { Link, useNavigate } from "@tanstack/react-router";
import { RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { Bar, EmptyState, PageHeader, StatusPill } from "@/components/ui/tessera";
import { CONCEPTS } from "@/data/concepts";
import { PRACTICE } from "@/data/practice";
import { useTessera } from "@/state/AppState";

export function ProgressPage() {
  const { state, dispatch, statuses, path } = useTessera();
  const navigate = useNavigate();
  const { results } = state;

  if (!results || !statuses) {
    return (
      <>
        <PageHeader eyebrow="Progress" title="How you're doing" />
        <EmptyState title="No progress to show yet" body="Take the diagnostic and your progress will build up here as you learn." />
      </>
    );
  }

  const mastered = CONCEPTS.filter((c) => statuses[c.id] === "mastered").length;
  const lessonsDone = state.completedSteps.length;
  const minutesDone = CONCEPTS.filter((c) => state.completedSteps.includes(c.id)).reduce((m, c) => m + c.minutes, 0);

  const stats = [
    { label: "Diagnostic score", value: `${results.score}/${results.total}`, note: results.answered < results.total ? `${results.total - results.answered} unanswered` : "all answered" },
    { label: "Concepts mastered", value: `${mastered}/${CONCEPTS.length}`, note: "diagnostic + lessons" },
    { label: "Lessons completed", value: String(lessonsDone), note: path.length ? `of ${path.length} in your path` : "no path needed" },
    { label: "Study time in lessons", value: `${minutesDone} min`, note: "estimated from lessons" },
  ];

  return (
    <>
      <PageHeader
        eyebrow="Progress"
        title="How you're doing"
        sub="Everything here comes from your actual answers and completed lessons."
        actions={
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => {
              dispatch({ type: "restart" });
              toast("Diagnostic restarted", { description: "Your previous answers and progress were cleared." });
              navigate({ to: "/app/diagnose" });
            }}
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" /> Retake diagnostic
          </button>
        }
      />

      <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="panel p-5">
            <dt className="eyebrow">{s.label}</dt>
            <dd className="mt-2 font-display text-4xl">{s.value}</dd>
            <p className="mt-1 text-xs text-muted-foreground">{s.note}</p>
          </div>
        ))}
      </dl>

      <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <section className="panel p-6" aria-labelledby="by-concept">
          <h2 id="by-concept" className="text-xl">
            By concept
          </h2>
          <ul className="mt-4 divide-y divide-border">
            {CONCEPTS.map((c) => {
              const r = results.concepts[c.id];
              const practiceCorrect = PRACTICE[c.id].filter((q) => state.lessonAnswers[q.id] === q.correct).length;
              return (
                <li key={c.id} className="flex flex-wrap items-center gap-x-4 gap-y-2 py-3">
                  <Link to="/app/concept/$id" params={{ id: c.id }} className="min-w-0 flex-1 text-sm font-medium hover:text-primary">
                    {c.name}
                  </Link>
                  <span className="text-xs text-muted-foreground">{r.answered ? `Diagnostic ${r.correct}/${r.answered}` : "Not assessed"}</span>
                  <span className="text-xs text-muted-foreground">
                    Practice {practiceCorrect}/{PRACTICE[c.id].length}
                  </span>
                  <StatusPill status={statuses[c.id]} />
                </li>
              );
            })}
          </ul>
        </section>

        <div className="space-y-5">
          <section className="panel p-6" aria-labelledby="overall">
            <h2 id="overall" className="text-xl">
              Overall mastery
            </h2>
            <div className="mt-4">
              <Bar value={mastered / CONCEPTS.length} label={`${mastered} of ${CONCEPTS.length} concepts mastered`} />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Mastered means correct in the diagnostic or lesson practice. Small samples can overstate understanding, so retest later.
            </p>
          </section>

          <section className="panel p-6" aria-labelledby="log">
            <h2 id="log" className="text-xl">
              Activity
            </h2>
            {state.activity.length === 0 ? (
              <p className="mt-3 text-sm text-muted-foreground">Nothing yet.</p>
            ) : (
              <ol className="mt-4 space-y-3">
                {state.activity.map((a) => (
                  <li key={a.id} className="border-l border-border pl-3">
                    <p className="text-sm font-medium">{a.label}</p>
                    <p className="text-xs text-muted-foreground">{a.detail}</p>
                  </li>
                ))}
              </ol>
            )}
          </section>
        </div>
      </div>
    </>
  );
}
