import { describe, expect, it } from "vitest";
import { CONCEPT_IDS } from "@/data/concepts";
import { PRACTICE, practiceComplete } from "@/data/practice";

describe("lesson practice", () => {
  it("every concept has two questions whose correct option exists", () => {
    for (const id of CONCEPT_IDS) {
      expect(PRACTICE[id]).toHaveLength(2);
      for (const q of PRACTICE[id]) expect(q.options[q.correct]).toBeTruthy();
    }
  });
  it("completion needs every question answered correctly", () => {
    const [a, b] = PRACTICE["variance"];
    expect(practiceComplete("variance", { [a!.id]: a!.correct })).toBe(false);
    expect(practiceComplete("variance", { [a!.id]: a!.correct, [b!.id]: "A" === b!.correct ? "B" : "A" })).toBe(false);
    expect(practiceComplete("variance", { [a!.id]: a!.correct, [b!.id]: b!.correct })).toBe(true);
  });
});
