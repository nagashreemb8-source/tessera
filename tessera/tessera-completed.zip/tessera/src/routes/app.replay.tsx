import { createFileRoute } from "@tanstack/react-router";
import { isConceptId } from "@/data/concepts";
import { ReplayPage } from "@/pages/Replay";
import type { ConceptId } from "@/types";

export const Route = createFileRoute("/app/replay")({
  validateSearch: (search: Record<string, unknown>): { concept?: ConceptId } => {
    const c = search["concept"];
    return typeof c === "string" && isConceptId(c) ? { concept: c } : {};
  },
  component: ReplayRoute,
});

function ReplayRoute() {
  const { concept } = Route.useSearch();
  return <ReplayPage concept={concept} />;
}
