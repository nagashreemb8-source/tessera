import { createFileRoute } from "@tanstack/react-router";
import { DiagnosePage } from "@/pages/Diagnose";

export const Route = createFileRoute("/app/diagnose")({
  component: DiagnosePage,
});
