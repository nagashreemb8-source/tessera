export type ConceptId =
  | "basic-probability"
  | "random-variables"
  | "expected-value"
  | "variance"
  | "probability-distributions"
  | "sampling-distributions"
  | "central-limit-theorem";

export type OptionKey = "A" | "B" | "C" | "D";
export type Status = "mastered" | "developing" | "untested";

export interface Concept {
  id: ConceptId;
  name: string;
  description: string;
  prerequisites: ConceptId[];
  minutes: number;
}

export interface Question {
  id: number;
  conceptIds: ConceptId[];
  /** Prerequisite this question also leans on (informational). */
  leansOn?: ConceptId | undefined;
  prompt: string;
  options: Record<OptionKey, string>;
  correct: OptionKey;
  commonErrors: Partial<Record<OptionKey, string>>;
}

export type Answers = Partial<Record<number, OptionKey>>;

export interface QuestionResult {
  id: number;
  chosen?: OptionKey | undefined;
  answered: boolean;
  correct: boolean;
}

export interface ConceptResult {
  conceptId: ConceptId;
  correct: number;
  answered: number;
  wrongIds: number[];
}

export interface QuizResults {
  questions: QuestionResult[];
  concepts: Record<ConceptId, ConceptResult>;
  score: number;
  answered: number;
  total: number;
}

export interface ObservedMistake {
  questionId: number;
  conceptIds: ConceptId[];
  chosen?: OptionKey | undefined;
  correctAnswer: OptionKey;
  pattern: string;
  unanswered: boolean;
}

export type EvidenceLevel = "Limited" | "Some" | "Stronger";

export interface FollowUp {
  conceptId: ConceptId;
  prompt: string;
  options: Record<OptionKey, string>;
  correct: OptionKey;
  /** Options that repeat the misconception seen in the diagnostic. */
  misconception: OptionKey[];
  misconceptionNote: string;
}

export interface SuspectedGap {
  conceptId: ConceptId;
  kind: "prerequisite" | "self";
  supportingQuestionIds: number[];
  dependentConceptIds: ConceptId[];
  supportedPrerequisites: ConceptId[];
  alternatives: string[];
  evidence: EvidenceLevel;
  needsMoreEvidence: boolean;
  summary: string;
  followUp?: FollowUp | undefined;
}

export interface Diagnosis {
  observed: ObservedMistake[];
  statuses: Record<ConceptId, Status>;
  gaps: SuspectedGap[];
}

export type HypothesisOutcome = "possible-gap" | "more-evidence" | "supported";

export interface HypothesisResult {
  conceptId: ConceptId;
  answer: OptionKey;
  outcome: HypothesisOutcome;
  title: string;
  explanation: string;
}

export interface PathStep {
  conceptId: ConceptId;
  verb: "Review" | "Revisit" | "Practice" | "Continue to" | "Reassess";
  reason: string;
  prerequisitesInPath: ConceptId[];
}
