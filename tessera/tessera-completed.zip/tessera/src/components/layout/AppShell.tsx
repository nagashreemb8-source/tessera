import { Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { ChevronRight, Compass, LayoutDashboard, LineChart, Network, PanelLeftClose, PanelLeftOpen, Route as RouteIcon, Settings } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { DemoBadge, Logo } from "@/components/ui/tessera";
import { CONCEPT_BY_ID, isConceptId } from "@/data/concepts";
import { SAMPLE_STUDENT } from "@/data/sampleStudent";
import { cn } from "@/lib/utils";
import { useTessera } from "@/state/AppState";

const NAV = [
  { to: "/app", label: "Overview", icon: LayoutDashboard },
  { to: "/app/diagnose", label: "Diagnose", icon: Compass },
  { to: "/app/map", label: "Knowledge Map", icon: Network },
  { to: "/app/path", label: "Learning Path", icon: RouteIcon },
  { to: "/app/progress", label: "Progress", icon: LineChart },
] as const;

const CRUMBS: Record<string, string> = {
  "/app": "Overview",
  "/app/diagnose": "Diagnose",
  "/app/results": "Results",
  "/app/replay": "Root Cause Replay",
  "/app/map": "Knowledge Map",
  "/app/path": "Learning Path",
  "/app/progress": "Progress",
};

function SettingsPanel({ collapsed }: { collapsed: boolean }) {
  const { state, dispatch } = useTessera();
  const navigate = useNavigate();
  return (
    <Popover>
      <PopoverTrigger className={cn("btn btn-quiet w-full justify-start", collapsed && "justify-center px-0")} aria-label="Settings">
        <Settings className="h-4 w-4 shrink-0" aria-hidden="true" />
        {!collapsed && "Settings"}
      </PopoverTrigger>
      <PopoverContent side="right" align="end" className="w-72 border-border bg-surface-2">
        <p className="text-sm font-medium">Demo settings</p>
        <p className="mt-1 text-xs text-muted-foreground">Progress is saved in this browser only (local storage). Nothing is sent anywhere in demo mode.</p>
        <button
          type="button"
          className="btn btn-secondary mt-4 w-full"
          onClick={() => {
            dispatch({ type: "reset" });
            toast.success("Demo reset", { description: "Answers, diagnosis and progress were cleared." });
            navigate({ to: "/app" });
          }}
        >
          Reset demo
        </button>
        <label className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
          <input
            type="checkbox"
            checked={state.simulateFailure}
            onChange={(e) => dispatch({ type: "simulateFailure", value: e.target.checked })}
            className="accent-primary"
          />
          Simulate a loading failure on Overview
        </label>
      </PopoverContent>
    </Popover>
  );
}

export function AppShell() {
  const [collapsed, setCollapsed] = useState(false);
  const { hydrated } = useTessera();
  const pathname = useRouterState({ select: (s) => s.location.pathname }).replace(/\/$/, "") || "/app";
  const isActive = (to: string) => (to === "/app" ? pathname === "/app" : pathname.startsWith(to));

  let crumb = CRUMBS[pathname];
  if (!crumb && pathname.startsWith("/app/concept/")) {
    const id = pathname.split("/").pop() ?? "";
    crumb = isConceptId(id) ? CONCEPT_BY_ID[id].name : "Concept";
  }

  return (
    <div className="flex min-h-screen w-full">
      <aside
        className={cn(
          "sticky top-0 hidden h-screen shrink-0 flex-col border-r border-border bg-surface transition-[width] duration-200 md:flex",
          collapsed ? "w-16" : "w-60",
        )}
      >
        <div className={cn("flex h-14 items-center border-b border-border px-4", collapsed && "justify-center px-0")}>
          <Link to="/" aria-label="Tessera home" className="rounded">
            <Logo compact={collapsed} />
          </Link>
        </div>
        <nav className="flex-1 space-y-1 p-2" aria-label="Main">
          {NAV.map((n) => {
            const active = isActive(n.to);
            return (
              <Link
                key={n.to}
                to={n.to}
                title={collapsed ? n.label : undefined}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "relative flex h-10 items-center gap-3 rounded-md px-3 text-sm transition-colors",
                  collapsed && "justify-center px-0",
                  active ? "bg-surface-2 text-foreground" : "text-muted-foreground hover:bg-surface-2/60 hover:text-foreground",
                )}
              >
                {active && <span className="absolute left-0 top-2 bottom-2 w-0.5 rounded bg-primary" aria-hidden="true" />}
                <n.icon className={cn("h-4 w-4 shrink-0", active && "text-primary")} aria-hidden="true" />
                {!collapsed && n.label}
              </Link>
            );
          })}
        </nav>
        <div className="space-y-1 border-t border-border p-2">
          <SettingsPanel collapsed={collapsed} />
          <div className={cn("flex items-center gap-3 rounded-md px-3 py-2", collapsed && "justify-center px-0")}>
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-surface-2 text-xs font-semibold" aria-hidden="true">
              MR
            </span>
            {!collapsed && (
              <span className="min-w-0 text-xs leading-tight">
                <span className="block truncate font-medium">{SAMPLE_STUDENT.name}</span>
                <span className="text-muted-foreground">demo student</span>
              </span>
            )}
          </div>
          <button
            type="button"
            className={cn("btn btn-quiet w-full justify-start", collapsed && "justify-center px-0")}
            onClick={() => setCollapsed((c) => !c)}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {collapsed ? <PanelLeftOpen className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
            {!collapsed && "Collapse"}
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b border-border bg-background/90 px-4 backdrop-blur md:px-8">
          <nav aria-label="Breadcrumb" className="flex min-w-0 items-center gap-1.5 text-sm">
            <Link to="/" className="md:hidden" aria-label="Tessera home">
              <Logo compact />
            </Link>
            <Link to="/app" className="hidden text-muted-foreground hover:text-foreground md:inline">
              Probability &amp; Statistics
            </Link>
            <ChevronRight className="hidden h-3.5 w-3.5 text-muted-foreground md:block" aria-hidden="true" />
            <span className="truncate font-medium" aria-current="page">
              {crumb ?? "Overview"}
            </span>
          </nav>
          <DemoBadge />
        </header>
        <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 pb-28 md:px-8 md:pb-12">
          {hydrated ? (
            <Outlet />
          ) : (
            <div role="status" aria-label="Loading your progress" className="space-y-4">
              <div className="h-9 w-2/3 animate-pulse rounded bg-surface-2" />
              <div className="h-40 animate-pulse rounded-lg bg-surface" />
            </div>
          )}
        </main>
      </div>

      <nav
        aria-label="Main"
        className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-surface/95 backdrop-blur md:hidden"
      >
        {NAV.map((n) => {
          const active = isActive(n.to);
          return (
            <Link
              key={n.to}
              to={n.to}
              aria-current={active ? "page" : undefined}
              className={cn("flex min-h-16 flex-col items-center justify-center gap-1 text-[11px]", active ? "text-primary" : "text-muted-foreground")}
            >
              <n.icon className="h-5 w-5" aria-hidden="true" />
              {n.label.replace("Knowledge ", "").replace("Learning ", "")}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
