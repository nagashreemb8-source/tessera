import { CONCEPTS, MAP_LAYOUT } from "@/data/concepts";
import { cn } from "@/lib/utils";
import type { ConceptId, Status } from "@/types";

const W = 158;
const H = 58;

export function KnowledgeGraph({
  statuses,
  selected,
  investigating,
  onSelect,
  compact = false,
  className,
}: {
  statuses: Record<ConceptId, Status>;
  selected?: ConceptId | null;
  investigating?: ConceptId | null;
  onSelect?: (id: ConceptId) => void;
  compact?: boolean;
  className?: string;
}) {
  const interactive = !!onSelect;
  return (
    <svg viewBox="0 0 1000 420" className={cn("h-auto w-full", className)} role={interactive ? "group" : "img"} aria-label="Concept dependency graph">
      <defs>
        <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
          <path d="M0,0 L10,5 L0,10 z" className="fill-muted-foreground/60" />
        </marker>
        <marker id="arrow-hot" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
          <path d="M0,0 L10,5 L0,10 z" className="fill-primary" />
        </marker>
      </defs>
      {CONCEPTS.flatMap((c) =>
        c.prerequisites.map((p) => {
          const a = MAP_LAYOUT[p];
          const b = MAP_LAYOUT[c.id];
          const x1 = a.x + W / 2;
          const x2 = b.x - W / 2 - 4;
          const mx = (x1 + x2) / 2;
          const hot = investigating && (p === investigating || c.id === investigating) || (selected && (p === selected || c.id === selected));
          return (
            <path
              key={`${p}-${c.id}`}
              d={`M${x1},${a.y} C${mx},${a.y} ${mx},${b.y} ${x2},${b.y}`}
              fill="none"
              strokeWidth={hot ? 1.8 : 1.2}
              markerEnd={hot ? "url(#arrow-hot)" : "url(#arrow)"}
              className={cn("transition-all duration-300", hot ? "stroke-primary animate-dash" : "stroke-muted-foreground/35")}
            />
          );
        }),
      )}
      {CONCEPTS.map((c) => {
        const { x, y } = MAP_LAYOUT[c.id];
        const s = statuses[c.id];
        const isSel = selected === c.id;
        const isInv = investigating === c.id;
        return (
          <g
            key={c.id}
            transform={`translate(${x - W / 2},${y - H / 2})`}
            className={cn("graph-node group outline-none", interactive && "cursor-pointer")}
            tabIndex={interactive ? 0 : undefined}
            role={interactive ? "button" : undefined}
            aria-pressed={interactive ? isSel : undefined}
            aria-label={interactive ? `${c.name}, ${s}${isInv ? ", under investigation" : ""}` : undefined}
            onClick={() => onSelect?.(c.id)}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onSelect?.(c.id);
              }
            }}
          >
            {isInv && <rect x={-6} y={-6} width={W + 12} height={H + 12} rx={12} className="fill-primary/10 stroke-primary/50 animate-soft-pulse" strokeWidth={1} />}
            <rect
              width={W}
              height={H}
              rx={8}
              strokeWidth={isSel || isInv ? 2 : 1}
              className={cn(
                "transition-all duration-200 group-focus-visible:stroke-primary group-hover:brightness-125",
                s === "mastered" && "fill-primary/10 stroke-primary/45",
                s === "developing" && "fill-developing/10 stroke-developing/60",
                s === "untested" && "fill-surface-2 stroke-muted-foreground/30",
                (isSel || isInv) && "stroke-primary",
              )}
              strokeDasharray={s === "untested" ? "4 4" : undefined}
            />
            <circle
              cx={16}
              cy={H / 2}
              r={4}
              className={cn(s === "mastered" && "fill-primary", s === "developing" && "fill-developing", s === "untested" && "fill-muted-foreground/60")}
            />
            <text x={28} y={compact ? H / 2 + 5 : H / 2 - 2} className="fill-foreground" style={{ fontSize: compact ? 15 : 14, fontWeight: 500 }}>
              {c.name.length > 17 ? c.name.replace("Probability ", "Prob. ").replace("Distributions", "Distrib.") : c.name}
            </text>
            {!compact && (
              <text x={28} y={H / 2 + 15} className="fill-muted-foreground" style={{ fontSize: 11 }}>
                {s === "untested" ? "not yet assessed" : s}
                {isInv ? " · investigating" : ""}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}

export function MapLegend() {
  const items = [
    { cls: "bg-primary/20 border-primary/60", label: "Mastered" },
    { cls: "bg-developing/20 border-developing/70", label: "Developing" },
    { cls: "bg-surface-2 border-muted-foreground/40 border-dashed", label: "Not yet assessed" },
    { cls: "border-primary glow-ring", label: "Under investigation" },
  ];
  return (
    <ul className="flex flex-wrap gap-x-5 gap-y-2 text-xs text-muted-foreground" aria-label="Legend">
      {items.map((i) => (
        <li key={i.label} className="flex items-center gap-2">
          <span className={cn("h-3 w-5 rounded-sm border", i.cls)} aria-hidden="true" />
          {i.label}
        </li>
      ))}
    </ul>
  );
}
