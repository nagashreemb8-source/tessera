# Backend contract (expected, NOT implemented in this repo)

The frontend runs fully offline in demo mode. Scoring, diagnosis, the learning path and
lesson practice are deterministic and local (`src/engine`, `src/data`).

Only one thing can use a backend: the "Still confused?" explanation
(`src/services/explanationService.ts`).

## Switching on
Copy `.env.example` to `.env` and set `VITE_API_BASE_URL=http://localhost:8000`.
Leave it empty for demo mode. Never put API keys in frontend files; the browser must
call only your backend, which calls NVIDIA/Nebius.

## Endpoint the frontend expects
`POST {VITE_API_BASE_URL}/api/explain` — **this endpoint is not provided here; your Python
backend must implement it (and enable CORS for the dev origin).**

Request:
```json
{
  "conceptId": "expected-value",
  "conceptName": "Expected Value",
  "evidence": [
    { "questionId": 3, "prompt": "...", "chosen": "B", "correct": "A", "pattern": "..." }
  ]
}
```
Response (200):
```json
{ "title": "string", "paragraphs": ["string", "..."], "note": "optional string" }
```

## Failure behaviour
Timeout (8 s), non-200, network error or a malformed body all fall back to the local template,
and the sheet is labelled "Demo explanation (backend unavailable)". The header badge shows
"Demo mode" without a backend URL and "Demo data · backend set" with one. It does not
claim the backend is reachable.
